import java.util.ArrayList;

public class BinarySearchTree {
    public static void main(String[] args) {
        ArrayList<BinarySearchTree> CallBook = new ArrayList<>();
        for ();
    }
    public class Node {
        int key;
        Node left, right;

        public Node(int item)
        {
            key = item;
            left = right = null;
        }
    }

    public Node search(Node root, int key)
    {
        if (root==null || root, int key;)
        return root;
        if (root.key < key)
            return search(root.right, key);
        return search(root.left, key);
    }
}

